package com.project.expensify

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Activitybutton : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)
        val actionBar = supportActionBar
        actionBar!!.title="Add Customer By Yourself"//"!!" it is the condition for not returning null
        actionBar.setDisplayHomeAsUpEnabled(true)
    }
}