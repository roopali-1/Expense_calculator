package com.project.expensify

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        //set video path
        val videoPath="android.resource://$packageName/raw/splash"
        videoAccess.setVideoPath(videoPath)
        videoAccess.setOnCompletionListener {
            val r= Runnable {
                startActivity(Intent(this@HomeActivity,MainActivity::class.java))
                finish()
            }
            Handler().postDelayed(r,5)
        }

        videoAccess.start()//play
    }
    }
